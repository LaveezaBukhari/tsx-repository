"use client"

import { motion } from "framer-motion"

interface TimelineItem {
  year: string
  title: string
  company: string
  description: string
}

interface TimelineProps {
  items: TimelineItem[]
  onMouseEnter?: () => void
  onMouseLeave?: () => void
}

export function Timeline({ items, onMouseEnter, onMouseLeave }: TimelineProps) {
  return (
    <div className="relative">
      {/* Vertical line */}
      <motion.div
        className="absolute left-[15px] md:left-1/2 top-0 bottom-0 w-0.5 bg-primary/20"
        initial={{ height: 0 }}
        animate={{ height: "100%" }}
        transition={{ duration: 1.5 }}
      />

      <div className="space-y-12">
        {items.map((item, index) => (
          <motion.div
            key={index}
            className="relative grid grid-cols-[30px_1fr] md:grid-cols-[1fr_30px_1fr]"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: index * 0.2 }}
            onMouseEnter={onMouseEnter}
            onMouseLeave={onMouseLeave}
          >
            {/* For desktop, show content on left for even items */}
            {index % 2 === 0 && (
              <div className="hidden md:block text-right pr-8">
                <div className="bg-card/30 backdrop-blur-sm p-4 rounded-lg border border-primary/10 shadow-sm">
                  <div className="text-sm font-medium text-primary mb-2">{item.year}</div>
                  <h3 className="text-xl font-bold">{item.title}</h3>
                  <h4 className="text-primary/80 font-medium">{item.company}</h4>
                  <p className="text-muted-foreground mt-2">{item.description}</p>
                </div>
              </div>
            )}

            {/* Circle indicator */}
            <div className="relative flex justify-center items-start">
              <motion.div
                className="w-6 h-6 rounded-full bg-primary/20 border-2 border-primary flex items-center justify-center mt-1"
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ delay: index * 0.2 + 0.2, type: "spring" }}
              >
                <motion.div
                  className="w-2 h-2 rounded-full bg-primary"
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ delay: index * 0.2 + 0.4 }}
                />
              </motion.div>
            </div>

            {/* For mobile and odd items on desktop */}
            <div className={`pl-4 md:pl-8 ${index % 2 === 0 ? "md:hidden" : ""}`}>
              <div className="bg-card/30 backdrop-blur-sm p-4 rounded-lg border border-primary/10 shadow-sm">
                <div className="text-sm font-medium text-primary mb-2">{item.year}</div>
                <h3 className="text-xl font-bold">{item.title}</h3>
                <h4 className="text-primary/80 font-medium">{item.company}</h4>
                <p className="text-muted-foreground mt-2">{item.description}</p>
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  )
}
