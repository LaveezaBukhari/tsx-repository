"use client"

import { motion } from "framer-motion"
import { ExternalLink, Github } from "lucide-react"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"

interface ProjectCardProps {
  title: string
  description: string
  tags: string[]
  image: string
  onMouseEnter?: () => void
  onMouseLeave?: () => void
}

export function ProjectCard({ title, description, tags, image, onMouseEnter, onMouseLeave }: ProjectCardProps) {
  return (
    <motion.div
      variants={{
        hidden: { opacity: 0, y: 50 },
        visible: { opacity: 1, y: 0 },
      }}
      whileHover={{ y: -10, transition: { duration: 0.3 } }}
      onMouseEnter={onMouseEnter}
      onMouseLeave={onMouseLeave}
    >
      <Card className="overflow-hidden h-full flex flex-col bg-card/50 backdrop-blur-sm border-primary/10">
        <div className="relative overflow-hidden h-48 group">
          <motion.div whileHover={{ scale: 1.05 }} transition={{ duration: 0.3 }} className="w-full h-full">
            <img src={image || "/placeholder.svg"} alt={title} className="w-full h-full object-cover" />
          </motion.div>
          <div className="absolute inset-0 bg-gradient-to-t from-background/80 to-transparent" />

          {/* Overlay with buttons that appear on hover */}
          <motion.div
            initial={{ opacity: 0 }}
            whileHover={{ opacity: 1 }}
            className="absolute inset-0 bg-primary/10 backdrop-blur-sm flex items-center justify-center opacity-0 transition-opacity"
          >
            <div className="flex gap-4">
              <Button size="sm" variant="secondary">
                <Github className="w-4 h-4 mr-2" />
                Code
              </Button>
              <Button size="sm">
                <ExternalLink className="w-4 h-4 mr-2" />
                Demo
              </Button>
            </div>
          </motion.div>
        </div>

        <CardContent className="flex-grow pt-6">
          <h3 className="text-xl font-bold mb-2">{title}</h3>
          <p className="text-muted-foreground mb-4">{description}</p>
          <div className="flex flex-wrap gap-2">
            {tags.map((tag, index) => (
              <Badge key={index} variant="secondary" className="bg-primary/10 text-primary hover:bg-primary/20">
                {tag}
              </Badge>
            ))}
          </div>
        </CardContent>

        <CardFooter className="border-t border-primary/10 p-4">
          <div className="flex gap-2 w-full">
            <Button variant="outline" size="sm" className="flex-1 group">
              <Github className="w-4 h-4 mr-2 group-hover:scale-110 transition-transform" />
              Code
            </Button>
            <Button size="sm" className="flex-1 group">
              <ExternalLink className="w-4 h-4 mr-2 group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" />
              Demo
            </Button>
          </div>
        </CardFooter>
      </Card>
    </motion.div>
  )
}
