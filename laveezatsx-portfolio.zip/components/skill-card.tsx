"use client"

import { motion } from "framer-motion"
import type { ReactNode } from "react"

interface SkillCardProps {
  icon: ReactNode
  title: string
  percentage: number
  onMouseEnter?: () => void
  onMouseLeave?: () => void
}

export function SkillCard({ icon, title, percentage, onMouseEnter, onMouseLeave }: SkillCardProps) {
  return (
    <motion.div
      whileHover={{ scale: 1.05 }}
      className="bg-card/50 backdrop-blur-sm p-4 rounded-lg shadow-sm border border-primary/10 flex flex-col gap-3"
      onMouseEnter={onMouseEnter}
      onMouseLeave={onMouseLeave}
    >
      <div className="flex items-center gap-3">
        <div className="text-primary bg-primary/10 p-2 rounded-md">{icon}</div>
        <span className="font-medium">{title}</span>
      </div>

      <div className="w-full bg-muted rounded-full h-2 overflow-hidden">
        <motion.div
          className="h-full bg-primary"
          initial={{ width: 0 }}
          animate={{ width: `${percentage}%` }}
          transition={{ duration: 1, delay: 0.5 }}
        />
      </div>

      <div className="text-right text-sm text-muted-foreground">{percentage}%</div>
    </motion.div>
  )
}
