"use client"

import { useEffect, useState } from "react"
import { motion } from "framer-motion"

interface CustomCursorProps {
  variant: "default" | "hover"
}

export function CustomCursor({ variant }: CustomCursorProps) {
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 })
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    // Only show custom cursor on desktop
    if (window.innerWidth < 768) return

    const mouseMove = (e: MouseEvent) => {
      setMousePosition({
        x: e.clientX,
        y: e.clientY,
      })
    }

    const mouseEnter = () => setIsVisible(true)
    const mouseLeave = () => setIsVisible(false)

    window.addEventListener("mousemove", mouseMove)
    document.body.addEventListener("mouseenter", mouseEnter)
    document.body.addEventListener("mouseleave", mouseLeave)

    // Show cursor initially if mouse is already in window
    setIsVisible(true)

    return () => {
      window.removeEventListener("mousemove", mouseMove)
      document.body.removeEventListener("mouseenter", mouseEnter)
      document.body.removeEventListener("mouseleave", mouseLeave)
    }
  }, [])

  const variants = {
    default: {
      width: 32,
      height: 32,
      backgroundColor: "rgba(124, 58, 237, 0.2)",
      borderColor: "rgba(124, 58, 237, 0.5)",
      x: mousePosition.x - 16,
      y: mousePosition.y - 16,
    },
    hover: {
      width: 64,
      height: 64,
      backgroundColor: "rgba(124, 58, 237, 0.1)",
      borderColor: "rgba(124, 58, 237, 0.8)",
      x: mousePosition.x - 32,
      y: mousePosition.y - 32,
    },
  }

  // Don't render on mobile
  if (typeof window !== "undefined" && window.innerWidth < 768) return null

  return (
    <>
      <motion.div
        className="fixed top-0 left-0 rounded-full border pointer-events-none z-50 hidden md:block"
        variants={variants}
        animate={variant}
        transition={{ type: "spring", stiffness: 500, damping: 28 }}
        style={{
          opacity: isVisible ? 1 : 0,
          x: mousePosition.x - (variant === "default" ? 16 : 32),
          y: mousePosition.y - (variant === "default" ? 16 : 32),
        }}
      />
      <motion.div
        className="fixed top-0 left-0 w-4 h-4 bg-primary rounded-full pointer-events-none z-50 hidden md:block"
        animate={{
          x: mousePosition.x - 8,
          y: mousePosition.y - 8,
          opacity: isVisible ? 1 : 0,
        }}
        transition={{ type: "spring", stiffness: 1000, damping: 28 }}
      />
    </>
  )
}
