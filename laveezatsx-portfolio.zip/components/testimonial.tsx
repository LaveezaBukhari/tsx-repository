"use client"

import { motion } from "framer-motion"
import { Quote } from "lucide-react"

interface TestimonialProps {
  quote: string
  author: string
  position: string
  company: string
  image: string
  onMouseEnter?: () => void
  onMouseLeave?: () => void
}

export function Testimonial({ quote, author, position, company, image, onMouseEnter, onMouseLeave }: TestimonialProps) {
  return (
    <motion.div
      variants={{
        hidden: { opacity: 0, y: 50 },
        visible: { opacity: 1, y: 0 },
      }}
      whileHover={{ y: -5 }}
      className="bg-card/50 backdrop-blur-sm p-6 rounded-lg shadow-sm border border-primary/10 relative"
      onMouseEnter={onMouseEnter}
      onMouseLeave={onMouseLeave}
    >
      <div className="absolute -top-4 -left-2 text-primary opacity-20">
        <Quote size={40} />
      </div>

      <div className="relative z-10">
        <p className="italic text-muted-foreground mb-6">{quote}</p>

        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-full overflow-hidden">
            <img src={image || "/placeholder.svg"} alt={author} className="w-full h-full object-cover" />
          </div>

          <div>
            <h4 className="font-bold">{author}</h4>
            <p className="text-sm text-muted-foreground">
              {position}, {company}
            </p>
          </div>
        </div>
      </div>
    </motion.div>
  )
}
