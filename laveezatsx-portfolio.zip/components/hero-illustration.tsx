"use client"

import { motion } from "framer-motion"

export function HeroIllustration() {
  return (
    <div className="relative w-full max-w-md h-[400px]">
      {/* Background circle */}
      <motion.div
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{ duration: 0.8, delay: 0.3 }}
        className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[300px] h-[300px] rounded-full bg-primary/10"
      />

      {/* Floating elements */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, delay: 0.6 }}
        className="absolute top-[20%] left-[15%] w-16 h-16 bg-primary/20 rounded-lg"
      >
        <motion.div
          animate={{
            y: [0, -10, 0],
            rotate: [0, 5, 0],
          }}
          transition={{
            repeat: Number.POSITIVE_INFINITY,
            duration: 4,
            ease: "easeInOut",
          }}
          className="w-full h-full flex items-center justify-center"
        >
          <div className="w-8 h-8 bg-primary rounded-md" />
        </motion.div>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, delay: 0.8 }}
        className="absolute bottom-[25%] right-[20%] w-20 h-20 bg-primary/20 rounded-full"
      >
        <motion.div
          animate={{
            y: [0, 10, 0],
            rotate: [0, -5, 0],
          }}
          transition={{
            repeat: Number.POSITIVE_INFINITY,
            duration: 5,
            ease: "easeInOut",
            delay: 0.5,
          }}
          className="w-full h-full flex items-center justify-center"
        >
          <div className="w-10 h-10 bg-primary rounded-full" />
        </motion.div>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, delay: 1 }}
        className="absolute top-[60%] left-[25%] w-14 h-14 bg-primary/20 rounded-md transform rotate-45"
      >
        <motion.div
          animate={{
            y: [0, -8, 0],
            rotate: [0, 10, 0],
          }}
          transition={{
            repeat: Number.POSITIVE_INFINITY,
            duration: 4.5,
            ease: "easeInOut",
            delay: 1,
          }}
          className="w-full h-full flex items-center justify-center"
        >
          <div className="w-7 h-7 bg-primary rounded-sm transform -rotate-45" />
        </motion.div>
      </motion.div>

      {/* Central element */}
      <motion.div
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 1, delay: 0.5 }}
        className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-40 h-40 bg-primary/30 rounded-full flex items-center justify-center"
      >
        <motion.div
          animate={{
            rotate: [0, 360],
          }}
          transition={{
            repeat: Number.POSITIVE_INFINITY,
            duration: 20,
            ease: "linear",
          }}
          className="absolute inset-0 rounded-full border-4 border-dashed border-primary/40"
        />
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ duration: 0.5, delay: 1 }}
          className="w-24 h-24 bg-primary rounded-full flex items-center justify-center text-white font-bold text-xl"
        >
          <span>L</span>
        </motion.div>
      </motion.div>

      {/* Orbiting element */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 1, delay: 1.2 }}
        className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[280px] h-[280px]"
      >
        <motion.div
          animate={{
            rotate: [0, 360],
          }}
          transition={{
            repeat: Number.POSITIVE_INFINITY,
            duration: 15,
            ease: "linear",
          }}
          className="relative w-full h-full"
        >
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-6 h-6 bg-primary rounded-full" />
        </motion.div>
      </motion.div>
    </div>
  )
}
