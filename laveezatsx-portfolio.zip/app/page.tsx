"use client"

import type React from "react"

import { useEffect, useRef, useState } from "react"
import { motion, useInView, useAnimation, useScroll } from "framer-motion"
import { Code, ExternalLink, Github, Mail, Palette, Send } from "lucide-react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { HeroSection } from "@/components/hero-section"
import { ProjectCard } from "@/components/project-card"
import { SkillCard } from "@/components/skill-card"
import { NavBar } from "@/components/nav-bar"
import { ParticleBackground } from "@/components/particle-background"
import { CustomCursor } from "@/components/custom-cursor"
import { Timeline } from "@/components/timeline"
import { Testimonial } from "@/components/testimonial"
import { ScrollProgress } from "@/components/scroll-progress"

export default function Portfolio() {
  const [cursorVariant, setCursorVariant] = useState("default")
  const { scrollYProgress } = useScroll()

  const handleMouseEnter = () => setCursorVariant("hover")
  const handleMouseLeave = () => setCursorVariant("default")

  return (
    <div className="min-h-screen bg-gradient-to-b from-background via-background/95 to-background/90 overflow-hidden">
      <CustomCursor variant={cursorVariant} />
      <ParticleBackground />
      <ScrollProgress progress={scrollYProgress} />
      <NavBar onMouseEnter={handleMouseEnter} onMouseLeave={handleMouseLeave} />

      {/* Hero Section */}
      <HeroSection />

      {/* About Section */}
      <AnimatedSection id="about">
        <div className="container px-4 py-24 relative">
          <SectionHeading title="About Me" />

          <div className="grid md:grid-cols-2 gap-10 items-center mt-16">
            <motion.div
              variants={{
                hidden: { opacity: 0, x: -50 },
                visible: { opacity: 1, x: 0 },
              }}
              className="space-y-6"
              onMouseEnter={handleMouseEnter}
              onMouseLeave={handleMouseLeave}
            >
              <h3 className="text-2xl font-bold">My Journey</h3>
              <p className="text-muted-foreground">
                I'm passionate about creating beautiful, functional digital experiences that solve real problems. With
                expertise in both design and development, I bring a unique perspective to every project.
              </p>
              <p className="text-muted-foreground">
                My approach combines creative thinking with technical precision, resulting in work that's not only
                visually stunning but also strategically sound and user-focused.
              </p>
              <div className="pt-4">
                <Button variant="outline" asChild>
                  <Link href="#contact">Let's Work Together</Link>
                </Button>
              </div>
            </motion.div>

            <motion.div
              variants={{
                hidden: { opacity: 0, x: 50 },
                visible: { opacity: 1, x: 0 },
              }}
              className="bg-muted/30 backdrop-blur-sm rounded-lg p-8 border border-primary/10 shadow-[0_0_15px_rgba(124,58,237,0.1)]"
            >
              <h3 className="text-2xl font-bold mb-6">My Skills</h3>
              <div className="grid grid-cols-2 gap-4">
                <SkillCard
                  icon={<Code className="w-5 h-5" />}
                  title="Web Development"
                  percentage={90}
                  onMouseEnter={handleMouseEnter}
                  onMouseLeave={handleMouseLeave}
                />
                <SkillCard
                  icon={<Palette className="w-5 h-5" />}
                  title="UI/UX Design"
                  percentage={85}
                  onMouseEnter={handleMouseEnter}
                  onMouseLeave={handleMouseLeave}
                />
                <SkillCard
                  icon={<Github className="w-5 h-5" />}
                  title="Version Control"
                  percentage={80}
                  onMouseEnter={handleMouseEnter}
                  onMouseLeave={handleMouseLeave}
                />
                <SkillCard
                  icon={<ExternalLink className="w-5 h-5" />}
                  title="Responsive Design"
                  percentage={95}
                  onMouseEnter={handleMouseEnter}
                  onMouseLeave={handleMouseLeave}
                />
              </div>
            </motion.div>
          </div>
        </div>
      </AnimatedSection>

      {/* Timeline Section */}
      <AnimatedSection id="experience">
        <div className="container px-4 py-24 relative">
          <SectionHeading title="My Experience" />

          <div className="mt-16">
            <Timeline
              items={[
                {
                  year: "2023 - Present",
                  title: "Senior Frontend Developer",
                  company: "Tech Innovations Inc.",
                  description:
                    "Leading the frontend development team, implementing modern UI/UX designs and optimizing performance.",
                },
                {
                  year: "2020 - 2023",
                  title: "UI/UX Designer & Developer",
                  company: "Creative Solutions",
                  description:
                    "Designed and developed responsive web applications with focus on user experience and accessibility.",
                },
                {
                  year: "2018 - 2020",
                  title: "Web Developer",
                  company: "Digital Agency",
                  description: "Built client websites and web applications using modern JavaScript frameworks.",
                },
              ]}
              onMouseEnter={handleMouseEnter}
              onMouseLeave={handleMouseLeave}
            />
          </div>
        </div>
      </AnimatedSection>

      {/* Projects Section */}
      <AnimatedSection id="projects">
        <div className="container px-4 py-24 relative">
          <SectionHeading title="My Projects" />

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mt-16">
            <ProjectCard
              title="E-Commerce Platform"
              description="A full-featured online store with payment integration and inventory management."
              tags={["Next.js", "Tailwind CSS", "Stripe"]}
              image="/placeholder.svg?height=400&width=600"
              onMouseEnter={handleMouseEnter}
              onMouseLeave={handleMouseLeave}
            />
            <ProjectCard
              title="Portfolio Website"
              description="A responsive portfolio website with animations and dark mode support."
              tags={["React", "Framer Motion", "Tailwind CSS"]}
              image="/placeholder.svg?height=400&width=600"
              onMouseEnter={handleMouseEnter}
              onMouseLeave={handleMouseLeave}
            />
            <ProjectCard
              title="Mobile App Design"
              description="UI/UX design for a fitness tracking mobile application."
              tags={["Figma", "UI Design", "Prototyping"]}
              image="/placeholder.svg?height=400&width=600"
              onMouseEnter={handleMouseEnter}
              onMouseLeave={handleMouseLeave}
            />
          </div>
        </div>
      </AnimatedSection>

      {/* Testimonials Section */}
      <AnimatedSection id="testimonials">
        <div className="container px-4 py-24 relative">
          <SectionHeading title="What Clients Say" />

          <div className="mt-16 grid md:grid-cols-2 gap-8">
            <Testimonial
              quote="Laveeza delivered an exceptional website that perfectly captured our brand's essence. The attention to detail and creative solutions exceeded our expectations."
              author="Sarah Johnson"
              position="Marketing Director"
              company="Innovate Co."
              image="/placeholder.svg?height=100&width=100"
              onMouseEnter={handleMouseEnter}
              onMouseLeave={handleMouseLeave}
            />
            <Testimonial
              quote="Working with Laveeza was a game-changer for our online presence. The website not only looks stunning but also performs incredibly well."
              author="Michael Chen"
              position="CEO"
              company="TechStart"
              image="/placeholder.svg?height=100&width=100"
              onMouseEnter={handleMouseEnter}
              onMouseLeave={handleMouseLeave}
            />
          </div>
        </div>
      </AnimatedSection>

      {/* Contact Section */}
      <AnimatedSection id="contact">
        <div className="container px-4 py-24 relative">
          <SectionHeading title="Get In Touch" />

          <div className="grid md:grid-cols-2 gap-10 mt-16">
            <motion.div
              variants={{
                hidden: { opacity: 0, y: 50 },
                visible: { opacity: 1, y: 0 },
              }}
              className="space-y-6"
              onMouseEnter={handleMouseEnter}
              onMouseLeave={handleMouseLeave}
            >
              <h3 className="text-2xl font-bold">Contact Information</h3>
              <p className="text-muted-foreground">
                I'm always open to discussing new projects, creative ideas or opportunities to be part of your vision.
              </p>

              <div className="space-y-4 pt-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                    <Mail className="text-primary w-5 h-5" />
                  </div>
                  <span>laveeza@example.com</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                    <Github className="text-primary w-5 h-5" />
                  </div>
                  <span>github.com/laveeza</span>
                </div>
              </div>
            </motion.div>

            <motion.div
              variants={{
                hidden: { opacity: 0, y: 50 },
                visible: { opacity: 1, y: 0 },
              }}
              className="bg-card/50 backdrop-blur-sm rounded-lg p-8 shadow-lg border border-primary/10"
              onMouseEnter={handleMouseEnter}
              onMouseLeave={handleMouseLeave}
            >
              <h3 className="text-2xl font-bold mb-6">Send Me a Message</h3>
              <form className="space-y-4">
                <div className="space-y-2">
                  <label htmlFor="name" className="text-sm font-medium">
                    Name
                  </label>
                  <Input id="name" placeholder="Your name" className="bg-background/50" />
                </div>
                <div className="space-y-2">
                  <label htmlFor="email" className="text-sm font-medium">
                    Email
                  </label>
                  <Input id="email" type="email" placeholder="Your email" className="bg-background/50" />
                </div>
                <div className="space-y-2">
                  <label htmlFor="message" className="text-sm font-medium">
                    Message
                  </label>
                  <Textarea id="message" placeholder="Your message" rows={4} className="bg-background/50" />
                </div>
                <Button type="submit" className="w-full group">
                  <Send className="w-4 h-4 mr-2 group-hover:translate-x-1 transition-transform" />
                  Send Message
                </Button>
              </form>
            </motion.div>
          </div>
        </div>
      </AnimatedSection>

      {/* Footer */}
      <footer className="bg-muted/30 backdrop-blur-sm py-8 border-t border-primary/10">
        <div className="container px-4 text-center">
          <p className="text-muted-foreground">© {new Date().getFullYear()} Laveeza. All rights reserved.</p>
        </div>
      </footer>
    </div>
  )
}

// Animated Section Component
function AnimatedSection({ children, id }: { children: React.ReactNode; id?: string }) {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, amount: 0.2 })
  const controls = useAnimation()

  useEffect(() => {
    if (isInView) {
      controls.start("visible")
    }
  }, [isInView, controls])

  return (
    <motion.section
      ref={ref}
      id={id}
      initial="hidden"
      animate={controls}
      variants={{
        hidden: { opacity: 0 },
        visible: {
          opacity: 1,
          transition: {
            staggerChildren: 0.2,
          },
        },
      }}
    >
      {children}
    </motion.section>
  )
}

// Section Heading Component
function SectionHeading({ title }: { title: string }) {
  return (
    <motion.div
      variants={{
        hidden: { opacity: 0, y: -20 },
        visible: { opacity: 1, y: 0 },
      }}
      className="text-center"
    >
      <h2 className="text-3xl md:text-4xl font-bold inline-block relative">
        {title}
        <motion.span
          className="absolute -bottom-2 left-0 w-full h-1 bg-primary rounded-full"
          variants={{
            hidden: { width: 0 },
            visible: {
              width: "100%",
              transition: { delay: 0.3, duration: 0.8 },
            },
          }}
        />
      </h2>
    </motion.div>
  )
}
