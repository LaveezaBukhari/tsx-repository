// DOM Elements
const body = document.body
const navbar = document.getElementById("navbar")
const menuToggle = document.getElementById("menu-toggle")
const closeMenu = document.getElementById("close-menu")
const mobileMenu = document.getElementById("mobile-menu")
const themeToggle = document.getElementById("theme-toggle")
const themeToggleMobile = document.getElementById("theme-toggle-mobile")
const scrollProgress = document.getElementById("scroll-progress")
const cursor = document.getElementById("cursor-outer")
const cursorDot = document.getElementById("cursor-dot")
const currentYear = document.getElementById("current-year")
const contactForm = document.getElementById("contact-form")
const skillCards = document.querySelectorAll(".skill-card")

// Set current year in footer
if (currentYear) {
  currentYear.textContent = new Date().getFullYear()
}

// Theme Toggle
function initTheme() {
  // Check for saved theme preference or use system preference
  const savedTheme = localStorage.getItem("theme")

  if (savedTheme === "dark") {
    document.documentElement.classList.add("dark")
  } else if (savedTheme === "light") {
    document.documentElement.classList.remove("dark")
  } else {
    // Use system preference
    if (window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches) {
      document.documentElement.classList.add("dark")
    }
  }
}

function toggleTheme() {
  if (document.documentElement.classList.contains("dark")) {
    document.documentElement.classList.remove("dark")
    localStorage.setItem("theme", "light")
  } else {
    document.documentElement.classList.add("dark")
    localStorage.setItem("theme", "dark")
  }
}

// Initialize theme
initTheme()

// Event Listeners
if (themeToggle) {
  themeToggle.addEventListener("click", toggleTheme)
}

if (themeToggleMobile) {
  themeToggleMobile.addEventListener("click", toggleTheme)
}

// Mobile Menu
if (menuToggle) {
  menuToggle.addEventListener("click", () => {
    mobileMenu.classList.add("open")
  })
}

if (closeMenu) {
  closeMenu.addEventListener("click", () => {
    mobileMenu.classList.remove("open")
  })
}

// Close mobile menu when clicking a link
document.querySelectorAll(".mobile-nav-link, .mobile-btn").forEach((link) => {
  link.addEventListener("click", () => {
    mobileMenu.classList.remove("open")
  })
})

// Navbar scroll effect
window.addEventListener("scroll", () => {
  if (window.scrollY > 10) {
    navbar.classList.add("scrolled")
  } else {
    navbar.classList.remove("scrolled")
  }

  // Update scroll progress
  if (scrollProgress) {
    const scrollPercentage = (window.scrollY / (document.documentElement.scrollHeight - window.innerHeight)) * 100
    scrollProgress.style.width = `${scrollPercentage}%`
  }
})

// Custom cursor
if (cursor && cursorDot && window.innerWidth >= 768) {
  document.addEventListener("mousemove", (e) => {
    cursor.style.opacity = "1"
    cursorDot.style.opacity = "1"
    cursor.style.transform = `translate(${e.clientX}px, ${e.clientY}px)`
    cursorDot.style.transform = `translate(${e.clientX}px, ${e.clientY}px)`
  })

  document.addEventListener("mouseout", () => {
    cursor.style.opacity = "0"
    cursorDot.style.opacity = "0"
  })

  // Add hover effect to interactive elements
  const interactiveElements = document.querySelectorAll(
    "a, button, .project-card, .skill-card, .testimonial-card, input, textarea",
  )

  interactiveElements.forEach((el) => {
    el.addEventListener("mouseenter", () => {
      cursor.classList.add("hover")
    })

    el.addEventListener("mouseleave", () => {
      cursor.classList.remove("hover")
    })
  })
}

// Skill progress bars
skillCards.forEach((card) => {
  const percentage = card.getAttribute("data-percentage")
  const progressBar = card.querySelector(".skill-progress")

  if (progressBar) {
    progressBar.style.setProperty("--percentage", `${percentage}%`)
  }
})

// Intersection Observer for animations
const observerOptions = {
  root: null,
  rootMargin: "0px",
  threshold: 0.1,
}

const observer = new IntersectionObserver((entries) => {
  entries.forEach((entry) => {
    if (entry.isIntersecting) {
      entry.target.classList.add("animate-in")
      observer.unobserve(entry.target)
    }
  })
}, observerOptions)

// Elements to animate on scroll
const animateElements = document.querySelectorAll(
  ".section-header, .about-content, .skills-grid, .timeline-item, .project-card, .testimonial-card, .contact-grid",
)

animateElements.forEach((el) => {
  observer.observe(el)
})

// Contact form submission
if (contactForm) {
  contactForm.addEventListener("submit", (e) => {
    e.preventDefault()

    // Get form data
    const formData = new FormData(contactForm)
    const name = formData.get("name")
    const email = formData.get("email")
    const message = formData.get("message")

    // Here you would typically send the data to a server
    // For this example, we'll just log it and show a success message
    console.log("Form submitted:", { name, email, message })

    // Show success message
    alert("Thank you for your message! I will get back to you soon.")

    // Reset form
    contactForm.reset()
  })
}
