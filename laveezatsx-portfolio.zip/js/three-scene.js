// Import Three.js library (if not already included in HTML)
import * as THREE from "three"

// 3D Scene with Three.js
const canvasContainer = document.getElementById("canvas-container")

if (canvasContainer && typeof THREE !== "undefined") {
  // Scene setup
  const scene = new THREE.Scene()

  // Camera setup
  const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000)
  camera.position.z = 5

  // Renderer setup
  const renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true })
  renderer.setSize(window.innerWidth, window.innerHeight)
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2))
  canvasContainer.appendChild(renderer.domElement)

  // Create particles
  const particlesGeometry = new THREE.BufferGeometry()
  const particlesCount = 2000

  const posArray = new Float32Array(particlesCount * 3)
  const colorArray = new Float32Array(particlesCount * 3)

  for (let i = 0; i < particlesCount * 3; i++) {
    // Position
    posArray[i] = (Math.random() - 0.5) * 10

    // Color - purple theme
    if (i % 3 === 0) {
      colorArray[i] = 0.6 + Math.random() * 0.4 // R
      colorArray[i + 1] = 0.2 + Math.random() * 0.3 // G
      colorArray[i + 2] = 0.9 + Math.random() * 0.1 // B
    }
  }

  particlesGeometry.setAttribute("position", new THREE.BufferAttribute(posArray, 3))
  particlesGeometry.setAttribute("color", new THREE.BufferAttribute(colorArray, 3))

  // Material
  const particlesMaterial = new THREE.PointsMaterial({
    size: 0.02,
    vertexColors: true,
    transparent: true,
    opacity: 0.8,
  })

  // Mesh
  const particlesMesh = new THREE.Points(particlesGeometry, particlesMaterial)
  scene.add(particlesMesh)

  // Add some lights
  const ambientLight = new THREE.AmbientLight(0xffffff, 0.5)
  scene.add(ambientLight)

  const pointLight = new THREE.PointLight(0x9c27b0, 1)
  pointLight.position.set(2, 3, 4)
  scene.add(pointLight)

  // Mouse interaction
  let mouseX = 0
  let mouseY = 0

  function onDocumentMouseMove(event) {
    mouseX = (event.clientX - window.innerWidth / 2) / 100
    mouseY = (event.clientY - window.innerHeight / 2) / 100
  }

  document.addEventListener("mousemove", onDocumentMouseMove)

  // Handle resize
  function onWindowResize() {
    camera.aspect = window.innerWidth / window.innerHeight
    camera.updateProjectionMatrix()
    renderer.setSize(window.innerWidth, window.innerHeight)
  }

  window.addEventListener("resize", onWindowResize)

  // Animation loop
  const clock = new THREE.Clock()

  function animate() {
    const elapsedTime = clock.getElapsedTime()

    // Rotate particles
    particlesMesh.rotation.x = elapsedTime * 0.05
    particlesMesh.rotation.y = -elapsedTime * 0.03

    // Mouse interaction
    particlesMesh.rotation.x += mouseY * 0.05
    particlesMesh.rotation.y += mouseX * 0.05

    // Render
    renderer.render(scene, camera)

    // Call animate again on the next frame
    requestAnimationFrame(animate)
  }

  animate()
}
